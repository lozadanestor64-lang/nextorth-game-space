package com.nextorth.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.nextorth.gamespace.START"
        const val ACTION_STOP = "com.nextorth.gamespace.STOP"
        private const val CHANNEL = "nextorth_game_space"
        private const val NOTIFICATION_ID = 2202
        private const val TAG = "NextorthOverlay"
    }

    private var wm: WindowManager? = null
    private var handle: View? = null
    private var panel: View? = null
    private val cornerTriggers = mutableListOf<View>()

    // -------------------------------------------------------------------
    // Ciclo de vida: TODO lo que puede fallar está envuelto en try/catch.
    // Un service en foreground que tira una excepción sin atajar se lleva
    // puesta a toda la app ("sigue fallando"), así que acá nunca dejamos
    // pasar una excepción hacia arriba.
    // -------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        try {
            wm = getSystemService(WINDOW_SERVICE) as? WindowManager
            createChannel()
        } catch (t: Throwable) {
            Log.e(TAG, "onCreate falló", t)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Lo primero, SIEMPRE: pasar a foreground. Si esto se demora o falla,
        // Android mata la app entera con "sigue fallando".
        try {
            startAsForeground()
        } catch (t: Throwable) {
            Log.e(TAG, "No se pudo iniciar en foreground", t)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            if (intent?.action == ACTION_STOP) {
                stopSelf()
                return START_NOT_STICKY
            }
            if (Settings.canDrawOverlays(this)) {
                if (handle == null) addHandle()
                if (cornerTriggers.isEmpty()) addCornerTriggers()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "No se pudieron crear las vistas del overlay", t)
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("NEXTORTH GAME SPACE")
            .setContentText("Menú gamer activo sobre los juegos")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, 0x4000)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // -------------------------------------------------------------------
    // Pestaña lateral (tocar o arrastrar para abrir el panel)
    // -------------------------------------------------------------------

    private fun addHandle() {
        val manager = wm ?: return
        if (handle != null || !Settings.canDrawOverlays(this)) return
        try {
            val h = TextView(this).apply {
                text = "≡\nGS"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.rgb(255, 25, 48), 24f)
                elevation = dp(12).toFloat()
                setOnClickListener { safe { showPanel() } }
                setOnTouchListener(HandleTouchListener())
            }
            val p = WindowManager.LayoutParams(
                dp(54), dp(142),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                y = dp(310)
            }
            manager.addView(h, p)
            handle = h
        } catch (t: Throwable) {
            Log.e(TAG, "No se pudo crear la pestaña", t)
            handle = null
        }
    }

    // -------------------------------------------------------------------
    // Zonas de esquina estilo RedMagic: un brillo rojo casi transparente
    // que marca dónde deslizar, y detecta el gesto para abrir el panel.
    // -------------------------------------------------------------------

    private fun addCornerTriggers() {
        val manager = wm ?: return
        if (cornerTriggers.isNotEmpty() || !Settings.canDrawOverlays(this)) return
        val corners = listOf(
            Gravity.TOP or Gravity.START,
            Gravity.TOP or Gravity.END,
            Gravity.BOTTOM or Gravity.START,
            Gravity.BOTTOM or Gravity.END
        )
        for (g in corners) {
            try {
                val zone = View(this).apply {
                    background = cornerGlow()
                    alpha = 0.55f
                }
                val p = WindowManager.LayoutParams(
                    dp(70), dp(70),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = g }
                zone.setOnTouchListener(CornerSwipeListener())
                manager.addView(zone, p)
                cornerTriggers.add(zone)
            } catch (t: Throwable) {
                Log.e(TAG, "No se pudo crear una esquina del overlay", t)
            }
        }
    }

    /** Brillo radial rojo, muy tenue, tipo acento de borde de RedMagic. */
    private fun cornerGlow(): GradientDrawable = GradientDrawable().apply {
        gradientType = GradientDrawable.RADIAL_GRADIENT
        gradientRadius = dp(60).toFloat()
        colors = intArrayOf(
            Color.argb(160, 255, 25, 48),
            Color.argb(60, 255, 25, 48),
            Color.argb(0, 255, 25, 48)
        )
    }

    // -------------------------------------------------------------------
    // Panel principal
    // -------------------------------------------------------------------

    private fun showPanel() {
        val manager = wm ?: return
        if (panel != null) return
        try {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = rounded(Color.rgb(8, 8, 8), 24f)
                elevation = dp(18).toFloat()
            }

            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val title = TextView(this).apply {
                text = "GAME SPACE"
                textSize = 22f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }
            top.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
            val close = TextView(this).apply {
                text = "×"
                textSize = 30f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(40, 40, 40), 18f)
                setOnClickListener { safe { hidePanel() } }
            }
            top.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
            root.addView(top)

            val line = TextView(this).apply { setBackgroundColor(Color.rgb(255, 25, 48)) }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(3)))

            val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, dp(6)) }
            stats.addView(stat("CPU", "BOOST"), LinearLayout.LayoutParams(0, dp(74), 1f))
            stats.addView(stat("GPU", "GAME"), LinearLayout.LayoutParams(0, dp(74), 1f))
            root.addView(stats)

            val boost = action("⚡  BOOST", "ACTIVAR")
            boost.setOnClickListener { safe { boost.text = "⚡  BOOST   ACTIVO" } }
            root.addView(boost, buttonLp())

            val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row1.addView(action("FPS", "60"), smallLp())
            row1.addView(action("BRILLO", "AUTO"), smallLp())
            root.addView(row1)

            val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row2.addView(action("🔕", "NO MOLESTAR"), smallLp())
            row2.addView(action("▣", "CAPTURA"), smallLp())
            root.addView(row2)

            val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row3.addView(action("●", "GRABAR"), smallLp())
            val exit = action("⏻", "CERRAR MENÚ")
            exit.setOnClickListener { safe { hidePanel() } }
            row3.addView(exit, smallLp())
            root.addView(row3)

            val note = TextView(this).apply {
                text = "MENÚ GAMER · NEXTORTH\nControles disponibles según Android y el dispositivo"
                textSize = 10f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
            }
            root.addView(note, LinearLayout.LayoutParams(-1, dp(42)))

            val metrics = resources.displayMetrics
            val width = (metrics.widthPixels * 0.88f).toInt().coerceAtMost(dp(390)).coerceAtLeast(dp(200))
            val height = (metrics.heightPixels * 0.72f).toInt().coerceAtLeast(dp(200))
            val p = WindowManager.LayoutParams(
                width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }
            manager.addView(root, p)
            panel = root
        } catch (t: Throwable) {
            Log.e(TAG, "No se pudo mostrar el panel", t)
            panel = null
        }
    }

    private fun stat(label: String, value: String): View = TextView(this).apply {
        text = "$label\n$value"
        gravity = Gravity.CENTER
        textSize = 14f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(24, 24, 24), 14f)
    }

    private fun action(label: String, sub: String): TextView = TextView(this).apply {
        text = "$label\n$sub"
        gravity = Gravity.CENTER
        textSize = 13f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(29, 29, 29), 14f)
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun buttonLp() = LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) }
    private fun smallLp() = LinearLayout.LayoutParams(0, dp(70), 1f).apply { topMargin = dp(8); marginEnd = dp(5) }

    private fun hidePanel() {
        val manager = wm
        panel?.let { view ->
            try {
                if (manager != null && view.isAttachedToWindow) manager.removeView(view)
            } catch (t: Throwable) {
                Log.e(TAG, "No se pudo cerrar el panel", t)
            }
        }
        panel = null
    }

    override fun onDestroy() {
        try { hidePanel() } catch (_: Throwable) {}
        val manager = wm
        try {
            handle?.let { if (manager != null && it.isAttachedToWindow) manager.removeView(it) }
        } catch (_: Throwable) {}
        handle = null
        cornerTriggers.forEach {
            try {
                if (manager != null && it.isAttachedToWindow) manager.removeView(it)
            } catch (_: Throwable) {}
        }
        cornerTriggers.clear()
        super.onDestroy()
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius.toInt()).toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "NEXTORTH Game Space", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Corre un bloque de UI atrapando cualquier excepción, para que nunca tire abajo el proceso. */
    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            Log.e(TAG, "Error en acción del overlay", t)
        }
    }

    /** Detecta un deslizamiento desde la esquina hacia el centro de la pantalla para abrir el panel. */
    private inner class CornerSwipeListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var triggered = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            return try {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        triggered = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!triggered) {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            val distance = kotlin.math.hypot(dx.toDouble(), dy.toDouble())
                            if (distance > dp(36)) {
                                triggered = true
                                safe { showPanel() }
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        triggered = false
                        true
                    }
                    else -> false
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Error en gesto de esquina", t)
                false
            }
        }
    }

    private inner class HandleTouchListener : View.OnTouchListener {
        private var downY = 0f
        private var startY = 0
        private var moved = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            return try {
                val manager = wm ?: return false
                val lp = v.layoutParams as? WindowManager.LayoutParams ?: return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downY = event.rawY; startY = lp.y; moved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dy) > dp(8)) moved = true
                        lp.y = (startY + dy).coerceIn(dp(80), resources.displayMetrics.heightPixels - dp(180))
                        try { manager.updateViewLayout(v, lp) } catch (_: Throwable) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) safe { showPanel() }; true }
                    MotionEvent.ACTION_CANCEL -> { moved = false; true }
                    else -> false
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Error en gesto de la pestaña", t)
                false
            }
        }
    }
}
