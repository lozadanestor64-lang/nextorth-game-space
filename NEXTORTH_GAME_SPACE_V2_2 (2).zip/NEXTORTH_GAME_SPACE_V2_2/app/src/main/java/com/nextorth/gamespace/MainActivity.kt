package com.nextorth.gamespace

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var permissionText: TextView
    private lateinit var menuButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionState()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(18), dp(28), dp(14))
            setBackgroundColor(Color.BLACK)
        }

        val brand = TextView(this).apply {
            text = "NEXTORTH"
            textSize = 16f
            setTextColor(Color.rgb(255, 32, 56))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand, lp(-1, -2))

        val title = TextView(this).apply {
            text = "GAME SPACE"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(title, lp(-1, -2))

        val sub = TextView(this).apply {
            text = "GAMING CENTER  ·  V2.2"
            textSize = 16f
            setTextColor(Color.LTGRAY)
        }
        root.addView(sub, lp(-1, -2))

        val gap1 = Space(this)
        root.addView(gap1, lp(1, dp(18)))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(Color.rgb(18, 18, 18))
        }
        val mode = TextView(this).apply {
            text = "MODO GAMING"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(mode, lp(-1, -2))
        permissionText = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(4), 0, dp(12))
        }
        card.addView(permissionText, lp(-1, -2))

        menuButton = Button(this).apply {
            text = "ACTIVAR MENÚ SOBRE LOS JUEGOS"
            textSize = 15f
            setTextColor(Color.WHITE)
            setAllCaps(false)
            setBackgroundColor(Color.rgb(255, 32, 56))
            setOnClickListener { onMenuPressed() }
        }
        card.addView(menuButton, lp(-1, dp(58)))
        root.addView(card, lp(-1, -2))

        val gap2 = Space(this)
        root.addView(gap2, lp(1, dp(20)))

        val gamesTitle = TextView(this).apply {
            text = "MIS JUEGOS"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(gamesTitle, lp(-1, -2))

        addGameButton(root, "Free Fire", "com.dts.freefireth")
        addGameButton(root, "Minecraft", "com.mojang.minecraftpe")
        addGameButton(root, "Roblox", "com.roblox.client")

        val spacer = Space(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val info = TextView(this).apply {
            text = "V2.2  ·  Android  ·  NEXTORTH GAME SPACE\nOverlay gamer estilo REDMAGIC"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        root.addView(info, lp(-1, dp(48)))

        setContentView(root)
    }

    private fun addGameButton(root: LinearLayout, name: String, pkg: String) {
        val b = Button(this).apply {
            text = name
            textSize = 17f
            setTextColor(Color.WHITE)
            setAllCaps(false)
            setBackgroundColor(Color.rgb(27, 27, 27))
            setOnClickListener { launchGame(name, pkg) }
        }
        val p = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) }
        root.addView(b, p)
    }

    private fun launchGame(name: String, pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            Toast.makeText(this, "$name no está instalado", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(intent)
            if (Settings.canDrawOverlays(this)) {
                startOverlayService()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir $name", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onMenuPressed() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primero activá 'Mostrar sobre otras apps'", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "No se pudo abrir el ajuste de permisos", Toast.LENGTH_SHORT).show()
            }
            return
        }
        startOverlayService()
        Toast.makeText(this, "Menú gamer activado. Tocá la pestaña roja o deslizá desde una esquina", Toast.LENGTH_LONG).show()
    }

    private fun startOverlayService() {
        try {
            val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar el menú gamer", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePermissionState() {
        if (!::permissionText.isInitialized) return
        val ok = Settings.canDrawOverlays(this)
        permissionText.text = if (ok) "● MENÚ SOBRE LOS JUEGOS LISTO" else "● FALTA ACTIVAR 'MOSTRAR SOBRE OTRAS APPS'"
        permissionText.setTextColor(if (ok) Color.rgb(255, 32, 56) else Color.LTGRAY)
        menuButton.text = if (ok) "ACTIVAR MENÚ SOBRE LOS JUEGOS" else "DAR PERMISO Y ACTIVAR MENÚ"
    }

    private fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
