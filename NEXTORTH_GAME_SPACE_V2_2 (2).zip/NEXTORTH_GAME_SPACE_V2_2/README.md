# NEXTORTH GAME SPACE V2.2

V2.2 mantiene el proyecto sin Jetpack Compose para evitar el fallo de compilador de versiones anteriores.

Cambios principales:
- Ícono de la app basado en la imagen Gamer Booster roja/negra proporcionada.
- Pestaña lateral roja visible y más grande.
- Panel overlay estilo gaming negro/rojo, inspirado en la distribución de los Game Space modernos.
- El panel se abre tocando la pestaña o deslizándola verticalmente.
- El botón de la app activa el overlay después de conceder "Mostrar sobre otras apps".
- Free Fire, Minecraft y Roblox se pueden lanzar desde la app si están instalados.

Nota: BOOST/FPS/BRILLO y demás controles son controles de interfaz. Un Android normal no permite a una app común forzar clocks de CPU/GPU o FPS del sistema sin APIs privilegiadas del fabricante.
